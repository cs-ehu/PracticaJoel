package pmyoo;

import java.awt.Color;
/**
 * Crea un enumerado con los colores de las filas
 * @author Joel Villalobos
 * @version 2017.06.04
 */

public enum ColorFila {
	ROJO(245, 255, 0, 15, 0, 15),VERDE(0, 40, 240, 255, 0, 15), AMARILLO(240, 255, 240, 255, 0, 15), AZUL(0, 15, 0, 15, 240, 255);
	ColorFila(int Rmin, int Rmax, int Gmin, int Gmax, int Bmin, int Bmax){
		
	}
}
